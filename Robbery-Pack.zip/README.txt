ROBBERY RESOURCE PACK (custom glove look)
==========================================

This folder is a Minecraft resource pack. The plain glove (glove.json, used when no tier applies) is a flat placeholder
icon; the 17 store gloves have their own 3D models (see DIFFERENT LOOKS PER GLOVE LEVEL below). To use your own 3D model:

1. In Blockbench make the glove (File > New > Java Block/Item model).
   - Give the texture a name like glove and keep the size a power of 2 (16, 32, 64...).
   - Set the "display" tab positions (first person, third person, GUI, ground) so it looks right in the hand.
2. Export: File > Export > Export Block/Item Model. You get glove.json (and the texture PNG).
3. Put the files in this folder, replacing the placeholders:
     assets/robbery/models/item/glove.json      <- your exported model
     assets/robbery/textures/item/glove.png     <- your texture
   Open glove.json in a text editor and make sure the texture lines say  "robbery:item/glove"  (not "item/glove" or
   a path from your computer). For example:   "textures": { "0": "robbery:item/glove", "particle": "robbery:item/glove" }
   If you have several texture files, copy them all into textures/item/ and use "robbery:item/<filename>".
4. Run   .\build-pack.ps1   in the project folder. It makes Robbery-Pack.zip and prints the SHA-1 hash.
5. Upload Robbery-Pack.zip somewhere with a DIRECT download link (the link must download the file, not show a web
   page). The link must be reachable without logging in, so a private GitHub release will NOT work.
6. In your server's server.properties set:
     resource-pack=<your direct link>
     resource-pack-sha1=<the hash from step 4>
     require-resource-pack=true        (optional)
   and restart the server.
7. In plugins/Robbery/glove.yml set    custom-looks: true    and run /ra reload. Gloves update on reload, on join and
   whenever the player upgrades.

Don't turn on custom-looks before the pack is live, or the glove shows as a purple-and-black missing model.

DIFFERENT LOOKS PER GLOVE LEVEL
-------------------------------
glove.yml has a "tiers" list with one glove per store (glove level N goes with store N, 17 in all). Every glove has a
finished blocky 3D model that shows the signature item of its store:
   1 Slurpee (7-Eleven)          7 Books, apple and pencil (School)    13 Marble column (Parthenon)
   2 Donut box (Dunkin Donuts)   8 Fossil (Museum)                     14 Trophy (Stadium)
   3 Coffee cup (Starbucks)      9 First-aid kit (Hospital)            15 Candelabra (Mansion)
   4 Pet paw (PetSmart)         10 Computer (Microsoft)                16 Stacks of money (Bank)
   5 Krabby patty (Krusty Krab) 11 Prison key (Prison)                 17 Crown (Royal Hall)
   6 Popcorn bucket (Cinema)    12 Flask (Laboratory)
The files are
     assets/robbery/models/item/glove_1.json  ...  glove_17.json
     assets/robbery/textures/item/glove_1.png ...  glove_17.png
     assets/robbery/items/glove_1.json        ...  glove_17.json     (what item-model in glove.yml refers to)

CHANGING A GLOVE OR MAKING A NEW ONE
Most models are made from a small text file in tools/gloves (glove_4.txt, glove_6.txt ...): coloured boxes and little pixel
pictures. Edit the text file and run, in the project folder:
     java tools/GloveKit.java build tools/gloves/glove_6.txt
It writes the model and the texture here and draws tools/gloves/preview/glove_6.png, a picture of the inventory icon, the
first-person view and every side, so you can see the result without starting the game. tools/gloves/README.txt explains the
text file. tools/gloves/preview/all.png shows all 17 icons together.
You can also make a model in Blockbench (steps above, saved as glove_N.json / glove_N.png with the texture lines saying
"robbery:item/glove_N"). Then run   java tools/GloveKit.java refit <model.json> <texture.png>   to set its size in the
inventory and in the hand the same way as the others (north is the front).
To add a tier: make models/item/glove_18.json, the texture and items/glove_18.json (build makes all three), then add a tier
to glove.yml pointing at "robbery:glove_18".

Changing the pack later: change the files, run build-pack.ps1, upload the new zip and put the new SHA-1 in
server.properties (players re-download when the hash changes).

RANK PICTURES (for chat and the tab list)
-----------------------------------------
Put a PNG in assets/robbery/textures/rank/ (name it with letters, numbers and _ only, like owner.png or crown.png).
A transparent background works. Run build-pack.ps1: it lists each picture as {img:name} and writes
assets/robbery/font/rank.json for you. Upload the new zip and update resource-pack-sha1 as usual. Then in
plugins/Robbery/chat.yml put {img:name} in a rank's "tag", for example   tag: "{img:crown} <gold>[VIP]"   and /ra reload.
The picture is scaled so it is one line of text tall (9 pixels), so draw it small and wide, like 30 x 9. crown.png is
an example. Without the pack loaded, players see an empty box instead of the picture.

MOVING COLOURS (a shader)
-------------------------
resourcepack/animated-colors.txt lists moving colours (rainbow, sunset, fire ...). build-pack.ps1 turns it into a text
shader (shader_69/assets/minecraft/shaders/core/rendertype_text.vsh and shader_69/assets/robbery/shaders/include/animated.glsl). In
chat.yml, tablist.yml and scoreboard.yml write <anim:fire>text</anim:fire> and the colours move on the player's screen,
in chat too, even for lines that were already sent. To make your own, add a line like
    mycolour = 0.5, 90 : #ff0000 #0000ff
(speed in rounds per second, length of one round in GUI pixels, then the colours), run build-pack.ps1 and upload the pack.
MINECRAFT VERSIONS
The pack works on Minecraft 1.21.9 and newer (pack.mcmeta says min_format 69, max_format 1000, so newer game versions do not
refuse it). The glove models, the item definitions and the rank pictures are the same on every version.
The moving-colour shader is different: Mojang rewrites the text shader between versions, and a shader written for one
version breaks on another. So there is one overlay folder per shader version, and pack.mcmeta turns each on only for the
resource pack formats it was written for (taken from the real game files of those versions):
    shader_69   formats 69 to 75   Minecraft 1.21.9, 1.21.10 and 1.21.11 (the same text shader in all three)
    shader_84   format 84          Minecraft 26.1.x (the lightmap is read with sample_lightmap)
    shader_88   format 88          Minecraft 26.2 (the text shader is now called text.vsh, one file for chat and the world)
On any other version the pack still loads (gloves, rank pictures), but the animated colours show as plain still colours.
When a new Minecraft version comes out: join with the pack, look at chat and the tab list, and if the text looks right
raise the "max_format" of the last overlay in pack.mcmeta. If the text looks wrong, that version needs its own overlay: copy the
latest one, and rewrite the vertex shader so it matches that version's original (the file is in the game jar, under
assets/minecraft/shaders/core/) with the three robbery lines added. build-pack.ps1 puts animated.glsl in every shader_* folder.
Old versions (before 1.21.9) are not supported by this pack.

NAME TAGS: the name above a player's head supports moving colours, also on the name itself. The text in front of the name (rank, prestige) comes from the
"nametag" part of tablist.yml, and text in the world is drawn by different game shaders than chat, so the shader folders also
override rendertype_text_see_through (the faint copy seen through walls). In the world there is no left-to-right position to
move along, so a tag changes colour all at once over time instead of the colour travelling along the text.
The game draws a name above a head in one of its 16 colours, so a moving name works like this: the tag text from Robbery
(tablist.yml, "nametag") contains the name in the player's own style, followed by a step back as wide as the name (the font
assets/robbery/font/nametag.json has one "step back" character for every width from 1 to 120 pixels). The game then draws its
own copy of the name over the styled one, in dark blue (#0000AA), and the shader hides text in exactly that colour in the
world. Because of this, do not use the exact colour #0000AA (<dark_blue>) in signs, holograms or other text in the world: it
would become invisible. If you do not want this, set styled-name: false under nametag in tablist.yml (the name is then drawn
by the game in white and cannot move). On a Minecraft version this pack has no shader for, a styled name shows its dark blue
copy on top of itself, so use styled-name: false if you support such versions.

The shader only changes text that is in these special colours and leaves all other text
alone. If it ever causes trouble (text looking wrong), delete the folders shader_69, shader_84 and shader_88 from the pack,
rebuild, and set animated-colors: false in chat.yml. Players using shader mods that replace core shaders may not see it move.
