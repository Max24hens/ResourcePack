ROBBERY RESOURCE PACK (custom glove look)
==========================================

This folder is a Minecraft resource pack. Right now the glove is a flat placeholder icon. To use your own 3D model:

1. In Blockbench make the glove (File > New > Java Block/Item model).
   - Give the texture a name like glove and keep the size a power of 2 (16, 32, 64...).
   - Set the "display" tab positions (first person, third person, GUI, ground) so it looks right in the hand.
2. Export: File > Export > Export Block/Item Model. You get glove.json (and the texture PNG).
3. Put the files in this folder, replacing the placeholders:
     assets/robbery/models/item/glove.json      <- your exported model
     assets/robbery/textures/item/glove.png     <- your texture
   Open glove.json in a text editor and make sure the texture lines say  "robbery:item/glove"  (not "item/glove" or
   a path from your computer). For example:   "textures": { "0": "robbery:item/glove", "particle": "robbery:item/glove" }
   If you have several texture files, copy them all into textures/item/ and use "robbery:item/<filename>".
4. Run   .\build-pack.ps1   in the project folder. It makes Robbery-Pack.zip and prints the SHA-1 hash.
5. Upload Robbery-Pack.zip somewhere with a DIRECT download link (the link must download the file, not show a web
   page). The link must be reachable without logging in, so a private GitHub release will NOT work.
6. In your server's server.properties set:
     resource-pack=<your direct link>
     resource-pack-sha1=<the hash from step 4>
     require-resource-pack=true        (optional)
   and restart the server.
7. In plugins/Robbery/glove.yml set    custom-looks: true    and run /ra reload. Gloves update on reload, on join and
   whenever the player upgrades.

Don't turn on custom-looks before the pack is live, or the glove shows as a purple-and-black missing model.

DIFFERENT LOOKS PER GLOVE LEVEL
-------------------------------
glove.yml has a "tiers" list with one glove per store (glove level N goes with store N, 15 in all):
  1 Slurpee (7-Eleven), 2 Donut Box (Dunken Donuts), 3 Coffee Cup (Star Bucks), 4 Fast Food (McDonalds),
  5 Grocery, 6 Museum, 7 Graveyard, 8 Bunker, 9 Krabby Patty (Krusty Krab), 10 Prison, 11 Tech (Microsoft),
  12 Jewelry, 13 Casino, 14 Bank, 15 Area 51.
To make each look, do the Blockbench steps above once per glove and save them as:
     assets/robbery/models/item/glove_1.json  ...  glove_15.json
     assets/robbery/textures/item/glove_1.png ...  glove_15.png
with the texture lines saying "robbery:item/glove_1" and so on. There are 17 gloves, one per store (see glove.yml and stores.yml). The files for glove_1 to glove_15 are finished blocky
models made for the first set of stores, and glove_16 and glove_17 are placeholder icons. Models that no longer match
their store: open any of them in Blockbench (File > Open Model) to see how they were built, and edit or replace them.
To add a tier: copy items/glove_5.json to items/glove_6.json (change the model name inside to robbery:item/glove_6),
add models/item/glove_6.json and the texture, then add a tier to glove.yml pointing at "robbery:glove_6".
Note the items/ folder: assets/robbery/items/glove_N.json is what item-model names refer to.

Changing the pack later: change the files, run build-pack.ps1, upload the new zip and put the new SHA-1 in
server.properties (players re-download when the hash changes).

RANK PICTURES (for chat and the tab list)
-----------------------------------------
Put a PNG in assets/robbery/textures/rank/ (name it with letters, numbers and _ only, like owner.png or crown.png).
A transparent background works. Run build-pack.ps1: it lists each picture as {img:name} and writes
assets/robbery/font/rank.json for you. Upload the new zip and update resource-pack-sha1 as usual. Then in
plugins/Robbery/chat.yml put {img:name} in a rank's "tag", for example   tag: "{img:crown} <gold>[VIP]"   and /ra reload.
The picture is scaled so it is one line of text tall (9 pixels), so draw it small and wide, like 30 x 9. crown.png is
an example. Without the pack loaded, players see an empty box instead of the picture.

MOVING COLOURS (a shader)
-------------------------
resourcepack/animated-colors.txt lists moving colours (rainbow, sunset, fire ...). build-pack.ps1 turns it into a text
shader (assets/minecraft/shaders/core/rendertype_text.vsh and assets/robbery/shaders/include/animated.glsl). In
chat.yml, tablist.yml and scoreboard.yml write <anim:fire>text</anim:fire> and the colours move on the player's screen,
in chat too, even for lines that were already sent. To make your own, add a line like
    mycolour = 0.5, 90 : #ff0000 #0000ff
(speed in rounds per second, length of one round in GUI pixels, then the colours), run build-pack.ps1 and upload the pack.
The shader is made for Minecraft 1.21.9. It only changes text that is in these special colours and leaves all other text
alone. If it ever causes trouble (text looking wrong), delete the folder assets/minecraft/shaders from the pack,
rebuild, and set animated-colors: false in chat.yml. Players using shader mods that replace core shaders may not see it move.
