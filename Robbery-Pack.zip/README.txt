ROBBERY RESOURCE PACK (custom glove look)
==========================================

This folder is a Minecraft resource pack. The plain glove (glove.json, used when no tier applies) is a flat placeholder
icon; the 17 store gloves have their own 3D models (see DIFFERENT LOOKS PER GLOVE LEVEL below). To use your own 3D model:

1. In Blockbench make the glove (File > New > Java Block/Item model).
   - Give the texture a name like glove and keep the size a power of 2 (16, 32, 64...).
   - Set the "display" tab positions (first person, third person, GUI, ground) so it looks right in the hand.
2. Export: File > Export > Export Block/Item Model. You get glove.json (and the texture PNG).
3. Put the files in this folder, replacing the placeholders:
     assets/robbery/models/item/glove.json      <- your exported model
     assets/robbery/textures/item/glove.png     <- your texture
   Open glove.json in a text editor and make sure the texture lines say  "robbery:item/glove"  (not "item/glove" or
   a path from your computer). For example:   "textures": { "0": "robbery:item/glove", "particle": "robbery:item/glove" }
   If you have several texture files, copy them all into textures/item/ and use "robbery:item/<filename>".
4. Run   .\build-pack.ps1   in the project folder. It makes Robbery-Pack.zip and prints the SHA-1 hash.
5. Upload Robbery-Pack.zip somewhere with a DIRECT download link (the link must download the file, not show a web
   page). The link must be reachable without logging in, so a private GitHub release will NOT work.
6. In your server's server.properties set:
     resource-pack=<your direct link>
     resource-pack-sha1=<the hash from step 4>
     require-resource-pack=true        (optional)
   and restart the server.
7. In plugins/Robbery/glove.yml set    custom-looks: true    and run /ra reload. Gloves update on reload, on join and
   whenever the player upgrades.

Don't turn on custom-looks before the pack is live, or the glove shows as a purple-and-black missing model.

DIFFERENT LOOKS PER GLOVE LEVEL
-------------------------------
glove.yml has a "tiers" list with one glove per store (glove level N goes with store N, 17 in all). Every glove has a
finished blocky 3D model that shows the signature item of its store:
   1 Slurpee (7-Eleven)          7 Books, apple and pencil (School)    13 Marble column (Parthenon)
   2 Donut box (Dunkin Donuts)   8 Fossil (Museum)                     14 Trophy (Stadium)
   3 Coffee cup (Starbucks)      9 First-aid kit (Hospital)            15 Candelabra (Mansion)
   4 Pet paw (PetSmart)         10 Computer (Microsoft)                16 Stacks of money (Bank)
   5 Krabby patty (Krusty Krab) 11 Prison key (Prison)                 17 Crown (Royal Hall)
   6 Popcorn bucket (Cinema)    12 Flask (Laboratory)
The files are
     assets/robbery/models/item/glove_1.json  ...  glove_17.json
     assets/robbery/textures/item/glove_1.png ...  glove_17.png
     assets/robbery/items/glove_1.json        ...  glove_17.json     (what item-model in glove.yml refers to)

CHANGING A GLOVE OR MAKING A NEW ONE
Most models are made from a small text file in tools/gloves (glove_4.txt, glove_6.txt ...): coloured boxes and little pixel
pictures. Edit the text file and run, in the project folder:
     java tools/GloveKit.java build tools/gloves/glove_6.txt
It writes the model and the texture here and draws tools/gloves/preview/glove_6.png, a picture of the inventory icon, the
first-person view and every side, so you can see the result without starting the game. tools/gloves/README.txt explains the
text file. tools/gloves/preview/all.png shows all 17 icons together.
You can also make a model in Blockbench (steps above, saved as glove_N.json / glove_N.png with the texture lines saying
"robbery:item/glove_N"). Then run   java tools/GloveKit.java refit <model.json> <texture.png>   to set its size in the
inventory and in the hand the same way as the others (north is the front).
To add a tier: make models/item/glove_18.json, the texture and items/glove_18.json (build makes all three), then add a tier
to glove.yml pointing at "robbery:glove_18".

ENCHANT MODELS
--------------
Two enchants show a creature of their own, made the same way (tools/gloves/black_hole.txt, phoenix_up.txt, phoenix_down.txt):
     black_hole                the Black Hole enchant: a black ball with a glowing ring. The game spins it around its middle.
     phoenix_up, phoenix_down  the Phoenix enchant: the same bird with its wings raised and lowered; the game swaps them to flap the wings.
                               The beak points north in the model: that is the way it flies.
These are not held in the hand: the middle of the model (8, 8, 8) is the point the game turns it around, so keep it there.
Which model an enchant uses is set in enchants.yml (model: / model-up: / model-down:). They show when custom-looks is on in glove.yml.

Changing the pack later: change the files, run build-pack.ps1, upload the new zip and put the new SHA-1 in
server.properties (players re-download when the hash changes).

RANK PICTURES (for chat and the tab list)
-----------------------------------------
Put a PNG in assets/robbery/textures/rank/ (name it with letters, numbers and _ only, like owner.png or crown.png).
A transparent background works. Run build-pack.ps1: it lists each picture as {img:name} and writes
assets/robbery/font/rank.json for you. Upload the new zip and update resource-pack-sha1 as usual. Then in
plugins/Robbery/chat.yml put {img:name} in a rank's "tag", for example   tag: "{img:crown} <gold>[VIP]"   and /ra reload.
The picture is scaled so it is one line of text tall (9 pixels), so draw it small and wide, like 30 x 9. crown.png is
an example. Without the pack loaded, players see an empty box instead of the picture.

MOVING COLOURS (a shader)
-------------------------
resourcepack/animated-colors.txt lists moving colours (rainbow, sunset, fire ...). build-pack.ps1 turns it into a text
shader (shader_69/assets/minecraft/shaders/core/rendertype_text.vsh and shader_69/assets/robbery/shaders/include/animated.glsl). In
chat.yml, tablist.yml and scoreboard.yml write <anim:fire>text</anim:fire> and the colours move on the player's screen,
in chat too, even for lines that were already sent. To make your own, add a line like
    mycolour = 0.5, 90 : #ff0000 #0000ff
(speed in rounds per second, length of one round in GUI pixels, then the colours), run build-pack.ps1 and upload the pack.
MINECRAFT VERSIONS
The pack works on Minecraft 1.21.9 and newer (pack.mcmeta says min_format 69, max_format 1000, so newer game versions do not
refuse it). The glove models, the item definitions and the rank pictures are the same on every version.
The moving-colour shader is different: Mojang rewrites the text shader between versions, and a shader written for one
version breaks on another. So there is one overlay folder per shader version, and pack.mcmeta turns each on only for the
resource pack formats it was written for (taken from the real game files of those versions):
    shader_69   formats 69 to 75   Minecraft 1.21.9, 1.21.10 and 1.21.11 (the same text shader in all three)
    shader_84   format 84          Minecraft 26.1.x (the lightmap is read with sample_lightmap)
    shader_88   format 88          Minecraft 26.2 (the text shader is now called text.vsh, one file for chat and the world)
On any other version the pack still loads (gloves, rank pictures), but the animated colours show as plain still colours.
When a new Minecraft version comes out: join with the pack, look at chat and the tab list, and if the text looks right
raise the "max_format" of the last overlay in pack.mcmeta. If the text looks wrong, that version needs its own overlay: copy the
latest one, and rewrite the vertex shader so it matches that version's original (the file is in the game jar, under
assets/minecraft/shaders/core/) with the three robbery lines added. build-pack.ps1 puts animated.glsl in every shader_* folder.
Old versions (before 1.21.9) are not supported by this pack.

NAME TAGS: the name above a player's head supports moving colours, also on the name itself. The text in front of the name (rank, prestige) comes from the
"nametag" part of tablist.yml, and text in the world is drawn by different game shaders than chat, so the shader folders also
override rendertype_text_see_through (the faint copy seen through walls). In the world there is no left-to-right position to
move along, so a tag changes colour all at once over time instead of the colour travelling along the text.
The game draws a name above a head in one of its 16 colours, so a moving name works like this: the tag text from Robbery
(tablist.yml, "nametag") contains the name in the player's own style, followed by a step back as wide as the name (the font
assets/robbery/font/nametag.json has one "step back" character for every width from 1 to 120 pixels). The game then draws its
own copy of the name over the styled one, in dark blue (#0000AA), and the shader hides text in exactly that colour in the
world. Because of this, do not use the exact colour #0000AA (<dark_blue>) in signs, holograms or other text in the world: it
would become invisible. If you do not want this, set styled-name: false under nametag in tablist.yml (the name is then drawn
by the game in white and cannot move). On a Minecraft version this pack has no shader for, a styled name shows its dark blue
copy on top of itself, so use styled-name: false if you support such versions.

The shader only changes text that is in these special colours and leaves all other text
alone. If it ever causes trouble (text looking wrong), delete the folders shader_69, shader_84 and shader_88 from the pack,
rebuild, and set animated-colors: false in chat.yml. Players using shader mods that replace core shaders may not see it move.

MENU PICTURES: a menu can be drawn by the pack: a whole background, pictures and text anywhere on it. The stores menu does this
(menus.yml, "stores-pictures": three stores on a page, each with a picture, its name and "Unlocked" or its price). It opens
instead of the plain stores menu when custom-looks is true in glove.yml (the line  pack-menu: stores-pictures  on the menu
"stores" does that; take the line out to keep the plain menu).
  - Every PNG in assets/robbery/textures/gui becomes one character of the font robbery:gui when build-pack.ps1 runs, and
    {gui:name} in a menu title draws it. gui-images.txt (next to this file) says how far down each picture sits and how high it
    is drawn. A PNG may be at most 256 x 256; a bigger PNG than its drawn height just gets sharper. A PNG that has no line
    in gui-images.txt stops build-pack.ps1 with a message, so add a line (name top height) for every picture of your own.
  - A store's picture: "picture: store_seven_eleven" under the store in stores.yml (the name of the PNG). A store without one
    shows store_default. The pictures in the pack are drawn by tools/GuiKit.java (run: java tools/GuiKit.java).
  - YOUR OWN SCREENSHOT of a store:  java tools/GuiKit.java picture seven_eleven C:/path/to/screenshot.png
    takes the middle square of the screenshot and saves it as store_seven_eleven.png (208 x 208, drawn 52 x 52). Then set the
    picture in stores.yml and run build-pack.ps1. GuiKit leaves a picture that came from a screenshot alone when it draws
    everything again; delete the PNG to get the drawn one back. (Take the screenshot with F1 pressed, so the hotbar is not in it.)
  - The fonts line73.json, line77.json ... write Minecraft's own letters on a line that many pixels below the menu's top edge
    (<font:robbery:line93> in a title). To write on another line, add its number to TEXT_LINES in tools/GuiKit.java.
  - The icons (gui_arrow_left, gui_back, enchant_gem_finder ...) are plain item models: item-model: "robbery:gui_back" on a
    button in menus.yml, icon-model: "robbery:enchant_gem_finder" on an enchant in enchants.yml. gui_blank draws nothing
    (for buttons that sit on a picture).
  - tools/gui/preview has pictures of how the menu and the icons look.

EVERY OTHER MENU of menus.yml gets the pack's look too when custom-looks is true: a dark background and the menu's title in
the middle. Three settings at the top of menus.yml (under "settings") do this:
  - pack-title: the title every menu gets. As it comes it is
         "{shift:-8}{gui:menu_bg_{rows}}{shift:-177}{center:176:<white><bold>{title}}"
    {rows} is the menu's number of rows and {title} is the menu's own title without its colours. So a menu of 3 rows draws
    the picture menu_bg_3 from its left edge, steps back, and writes its title in white in the middle of its 176 pixels.
    A menu can have a "pack-title:" of its own (next to its "title:"). pack-title: "" keeps the menu's normal title, with no
    background. A menu whose own title already draws a picture with {gui:...} (stores-pictures) is left alone.
  - pack-filler: false leaves the empty slots empty, because the background draws the slots. A menu can set its own
    "pack-filler: true" to get its filler item back (a menu that keeps its normal title with pack-title: "" wants that too).
  - pack-models: the look of the buttons, by the name a button has under "items:" in menus.yml. As it comes: back, previous,
    next, wallet, money, gems, rubies, prestige, enchants, stores, gloves, cosmetics, backpack and tool. A button called "back"
    shows robbery:gui_back in every menu, and so on. Add a line   name: "robbery:model"   for another button name. To switch
    one off write   back: ""   (a line you take out comes back from the plugin's own menus.yml).
    A button can have its own "pack-model:", and pack-model: "" keeps its normal item. A button with an "item-model:" is left
    alone. The looks of a list ("states") have no button name: they only take a "pack-model:" of their own.
  - The backgrounds are menu_bg_1.png to menu_bg_6.png in assets/robbery/textures/gui, one for every number of rows: 176
    pixels wide and 114 + 18 x rows high. tools/GuiKit.java draws them (run: java tools/GuiKit.java). Their lines in
    gui-images.txt are   menu_bg_1  0  132   to   menu_bg_6  0  222   (top 0 = right at the top edge, then the height).
  - The lootbox's "Loot Table" menu is not in menus.yml, so it keeps its plain title and filler.

ITEMS WITH A MODEL OF THE PACK: these settings give an item a model of the pack. A model is written like "robbery:crate_gold",
which is the file assets/robbery/items/crate_gold.json.
  - backpack.yml, item-model on a tier ("robbery:backpack_1" to "robbery:backpack_5"): the backpack in the hotbar shows the
    model instead of the head. A tier without one keeps the model of the tier below it; with no item-model at all the head
    stays. (An item-model under "item:" is used as long as no tier up to the player's own has one.)
  - crates.yml, on a crate: icon-model ("robbery:crate_gold") is the crate in the /crates menu, key-model ("robbery:key_gold")
    is shown where one of its keys is a reward. A crate without a key-model shows its icon-model for the key (the Cosmetic Case).
  - lootboxes.yml, icon-model on a box ("robbery:lootbox_heist"): the lootbox item, the box at the top of its Loot Table menu
    and the box where it is a reward.
  - A single reward (a line under "rewards:" in crates.yml, under "table:" or "jackpot:" in lootboxes.yml) can have its own
    icon-model, and that one wins:   {type: perk-ticket, amount: 1, weight: 2, icon-model: "robbery:my_ticket"}
    All pouches of one kind: icon-model under pouches, money / gems / rubies, in crates.yml.
    The models show in the lists of rewards (the crate's "Rewards" menu and the lootbox's Loot Table). The "You won!" menu
    of a crate and the items that fly around in the lootbox animation show the plain items.
  - enchants.yml, icon-model on an enchant ("robbery:enchant_gem_finder"): the enchant's icon in the menus.
  - The backpack, crate and lootbox models are blocky 3D models made like the gloves, from the text files in tools/gloves:
    backpack_1.txt to backpack_5.txt, crate_grind.txt, crate_iron.txt, crate_gold.txt, crate_diamond.txt,
    crate_cosmetic_case.txt and lootbox_heist.txt. Change a text file and run, in the project folder:
         java tools/GloveKit.java build tools/gloves/crate_gold.txt
    One file at a time: build-all only builds the gloves. It writes models/item/crate_gold.json, textures/item/crate_gold.png
    and items/crate_gold.json here and draws tools/gloves/preview/crate_gold.png. tools/gloves/README.txt explains the text
    file. A new text file with   model my_crate   makes the model "robbery:my_crate".
  - The keys (key_grind, key_iron, key_gold, key_diamond) are flat pictures like the button and enchant icons: tools/GuiKit.java
    draws them.
  - After a change to the pack: run build-pack.ps1, upload the new zip and put the new SHA-1 in server.properties.
    After a change to a yml file: /ra reload.

ALL OF THIS ONLY SHOWS WHEN custom-looks IS true in glove.yml. With false the menus keep their normal titles and fillers, and
the backpack, the crates, the lootboxes and the enchants show their plain items and heads. The one exception is "item-model:"
on a button in menus.yml: it is always put on the button, so use it in menus that only open with the pack (stores-pictures)
and use "pack-model:" everywhere else.
