#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <robbery:animated.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // Robbery: the same moving colours as in rendertype_text.vsh, for the faint see-through copy of a name tag.
    float animX = abs(ProjMat[2][3]) > 0.5 ? 0.0 : Position.x;
    vertexColor = robbery_animate(Color, animX, GameTime);
    texCoord0 = UV0;
}
