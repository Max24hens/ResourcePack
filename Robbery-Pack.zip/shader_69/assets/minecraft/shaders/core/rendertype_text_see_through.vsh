#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <robbery:animated.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // Robbery: the same moving colours as in rendertype_text.vsh, for the faint see-through copy of a name tag.
    bool worldText = abs(ProjMat[2][3]) > 0.5;
    float animX = worldText ? 0.0 : Position.x;
    vertexColor = robbery_animate(Color, animX, GameTime);
    // Hide the game's own copy of a player's name (dark blue #0000AA), see rendertype_text.vsh.
    if (worldText && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(0, 0, 170)))) vertexColor.a = 0.0;
    texCoord0 = UV0;
}
