#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <robbery:animated.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    // Robbery: text in one of the marker colours from animated-colors.txt gets a moving colour (see animated.glsl).
    // Every other colour is unchanged, so the rest of the text looks exactly as in vanilla.
    vec4 animatedColor = robbery_animate(Color, Position.x, GameTime);
    vertexColor = animatedColor * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
